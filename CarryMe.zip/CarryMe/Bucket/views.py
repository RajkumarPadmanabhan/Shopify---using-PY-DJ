from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import authenticate, login ,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .models import Product, Cart

# Create your views here.
def signuppage(request):
    user=None
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']
        email=request.POST['email']
        # print("---------->",username,password,email)
        try:
            user= User.objects.create_user(username=username,password=password,email=email)
            return redirect('loginpage')
        except :
            return redirect('signuppage') #UNIQUE USERNAME
        
    return render(request, 'usersignup.html',{'user':user})


def loginpage(request):
    if request.POST:
        username=request.POST['username']
        password=request.POST['password']
        luser=authenticate(username=username,password=password)
        if luser:
            login(request,luser)
            return redirect('indexpage') #LOGIN >> PROFILE
    return render(request, 'userlogin.html')

@login_required(login_url='loginpage')
def indexpage(request):
    lusername=request.user.username
    products = Product.objects.all()
    cart_items = Cart.objects.all()
    total = sum(item.total_price() for item in cart_items)
    return render(request,'index.html',{'lusername':lusername,'products': products,'total': total,'cart_items': cart_items})


def log_outt(request):
    logout(request)
    return redirect('loginpage')


def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if product.quantity > 0:
        cart_item, created = Cart.objects.get_or_create(product=product)
        if created:
            cart_item.quantity = 1  # Set initial quantity
        else:
            cart_item.quantity += 1  # Increment quantity
        cart_item.save()

        # Reduce product quantity
        product.quantity -= 1
        product.save()
    return redirect('indexpage')


def cart_view(request):
    cart_items = Cart.objects.all()
    total = sum(item.total_price() for item in cart_items)
    return render(request, 'cart.html', {'cart_items': cart_items, 'total': total})

def remove_from_cart(request, cart_id):
    cart_item = get_object_or_404(Cart, id=cart_id)
    cart_item.quantity -= 1  # Decrease cart item quantity
    if cart_item.quantity <= 0:
        cart_item.delete()  # Remove item if quantity is 0
    else:
        cart_item.save()

    # Increase product quantity back in stock
    cart_item.product.quantity += 1
    cart_item.product.save()
    return redirect('indexpage')


def empty_cart(request):
    # Restore product quantities
    for cart_item in Cart.objects.all():
        cart_item.product.quantity += cart_item.quantity
        cart_item.product.save()
    # Clear the cart
    Cart.objects.all().delete()
    return redirect('indexpage')